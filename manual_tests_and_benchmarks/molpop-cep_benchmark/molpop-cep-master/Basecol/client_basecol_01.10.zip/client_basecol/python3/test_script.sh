#!/bin/bash
rm -r ./output/*
./execute.py -c
./execute.py -c
ls ./output
./execute.py
./execute.py
ls ./output
./execute.py -a
./execute.py -a
ls ./output
