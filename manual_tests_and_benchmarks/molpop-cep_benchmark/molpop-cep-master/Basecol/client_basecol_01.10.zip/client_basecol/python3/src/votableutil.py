from VOTable import VOTable
import types


def getParamValue (table, name):
	"""
		return the content of a param field in a votable according to its id 

			votable : votable containing the informations
			name : name of the attribute to look for
	"""

	params = table.PARAM

	if(type(params)== list) : 
		for i in params :
			attr = i.getAttributes ()
			if (attr.get ('ID') == name) :
				return attr.get ('value')
	else :
		attr = params.getAttributes ()
		return attr.get ('value')

	
	return "no title defined"
		
	

def getParams (table):
	"""
		return the content of a param field in a votable according to its name 

			votable : votable containing the informations
			name : name of the attribute to look for
	"""
	params = table.root.VOTABLE.RESOURCE.PARAM
	values ={}
	for i, pm in enumerate (params) :
		attr = pm.getAttributes ()
		values[attr.get ('ID')] = attr.get ('value')
		
	return values	
	
 
def getFieldsDescription (table):
	"""
		return the content of a param field in a votable according to its id 

			votable : votable containing the informations
			name : name of the attribute to look for
	"""
	res = []
	fields = table.FIELD
	for elem in fields:
		try:
			res.append (elem.DESCRIPTION.getContent())
		except:
			pass
	return res
	
 
def getFieldData(votable, fieldName):
	"""
	 	return the content of the TDs in a list of lists in the table according a FIELD name
	
			votable : votable containing the informations
			fieldName : name of the field
	"""	
	rows = votable.getDataRows ()	
	listeCoeff = []	
	for row in rows:
		array = votable.getColumnIdx (fieldName)
		coeff =(votable.getSelectedData (row, array[0]))
		#if ((coeff in listeCoeff) == 0) :
		listeCoeff.append(coeff)
			
	return listeCoeff
		

def getTable (votable, name):
	"""
		return the content of a param field in a votable according to its name 

			votable : votable containing the informations
			name : name of the attribute to look for
	"""
	params = votable.getParams ()
	for i, pm in enumerate (params) :
		attr = pm.getAttributes ()
		if (attr.get ('name') == name) :
			return attr.get ('value')
		
	return "no title defined"
	

	

def getTableRows(table) :
	tableData = table.DATA.TABLEDATA
	return tableData._nodeList


def getTableColumn(table, val) :
	fields = table.FIELD	
	elementsList = []
	for coln, f in enumerate (fields):
		if val in list(f._attributes.values()):
			elementsList.append(coln)
	return elementsList
		
		

def getSelectedData (row, position):
	res = []
	list = row._nodeList
	count = 0
	for elm in list:
		try:
			if count == position:
				res.append (elm.getContent ())
				count = count + 1
			else:
				count = count + 1
		except:
			res.append ('')
	return res
			
			
###
def getFieldsAttrs (table):
	"""	Returns a list of maps that contains attributes.
		Returned list looks like this: [{},{},...]
	"""
	res = []
	fields = table.FIELD
	for elem in fields:
		try:
			res.append (elem.getAttributes())
		except:
			pass
	return res
