from xml.dom import minidom

#
# classe lisant le fichier de config 
#

class ConfigReader:


	def __init__(self, path):
		"""
		 	constructeur
				path : chemin du fichier de config xml a lire
		"""
		# url du fichier de configuration
		self.configFile = path
		self.xmldoc = minidom.parse(self.configFile)
		

	def getServer(self):
		"""
		 	recupere le contenu de la balise SERVER dans le fichier xml
		"""
		server = self.xmldoc.getElementsByTagName('SERVER')
		return  server[0].firstChild.data
	

	def getCollisionsUrl(self):
		"""
		 	recupere le contenu de la balise URL dans le fichier xml
		"""
		url = self.xmldoc.getElementsByTagName('COLLISIONS_URL')
		return  url[0].firstChild.data
		
	def getElementsUrl(self):
		"""
		 	recupere le contenu de la balise URL dans le fichier xml
		"""
		url = self.xmldoc.getElementsByTagName('ELEMENTS_URL')
		return  url[0].firstChild.data		
	
 
	def getMethod(self):
		"""
		 	recupere le contenu de la balise METHOD dans le fichier xml
		"""
		method = self.xmldoc.getElementsByTagName('METHOD')
		return  method[0].firstChild.data
	

	def getOutputDirectory(self):
		"""
		 	recupere le contenu de la balise OUTPUT_DIRECTORY dans le fichier xml
		"""
		outputDirectory = self.xmldoc.getElementsByTagName('OUTPUT_DIRECTORY')
		return  outputDirectory[0].firstChild.data
	
	def getXMLFileName(self):
		"""
			recupere le contenu de la balise XML_FILE_NAME dans le fichier xml
		"""
		xmlFile = self.xmldoc.getElementsByTagName('XML_FILE_NAME')
		return  xmlFile[0].firstChild.data

