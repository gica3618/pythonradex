from http.client import HTTPConnection
import shutil
import filecmp
import datetime
import string
import os

import filewriter 
import constants
import votableutil
from VOTable import VOTable

def readElementFile(allElements):
	""" 
		reads the elements configuration file
			allElements True if all elements are processed
	"""
	try : 
		file = open(constants.Global.elementFile)
		lines = file.readlines()
		elementSet = set([])
		
		if allElements == False :
			for i in range(len(lines)) :
				if lines[i].startswith(constants.ElementList.commentIndicator) == False:
					parts = lines[i].partition(constants.ElementList.commentIndicator)
					elementSet.add(parts[0].strip())
		else :
			for i in range(len(lines)) :
				#remove comments
				if lines[i].startswith(constants.ElementList.commentIndicator) == True:
					lines[i] = lines[i].replace(constants.ElementList.commentIndicator, "", 1)
					
				parts = lines[i].partition(constants.ElementList.commentIndicator)
				elementSet.add(parts[0].strip())
				
		return elementSet
	except IOError :
		print(" I/O error : elements.txt file does not exist. Please run the program with -e option")
		return False
	


def getFiles(server, method, tmpfile, outputDir, votable, datatype, allElements, allFiles) :
	"""
		gets the distant votables from their url	
		   server : server url
		   method : method used for the connection (get or post)
		   tmpfile : temporary file to store downloaded data
		   outputDir : directory where data are stored
		   votable : votable containing data
		   datatype : type of data to download
		   allElements : true if all elements in the file are downloaded
		   allFiles : true if all data files are written
	"""
	i=0
	name=""
	#flag, False when at least one element is available in the database
	noElement = True
	#get all the urls contained in the table
	fileList = votableutil.getFieldData(votable, constants.CollisionTable.collisionReferences)	
	elementList = votableutil.getFieldData(votable, constants.CollisionTable.targetElement)
	#list of elements selected by user
	chosenElementList = readElementFile(allElements)
	
	if chosenElementList == False :
		return False
	
	if allFiles == True :
		filewriter.createMoldat(outputDir)
	
	for value in fileList :		
		if elementList[i][0] in chosenElementList :
			noElement = False
			#remove "http://"
			urlPartielle=value[0].replace("http://", '')
			#remove the server address
			urlPartielle=urlPartielle.replace(server, '')
			print ("processing "+elementList[i][0]+" data\n")
			connection = HTTPConnection(server)
			connection.request(method, urlPartielle)		
			open(tmpfile,"wb").write(connection.getresponse().read())
			connection.close()

			votable = VOTable(tmpfile)

			tableParams = votableutil.getParams(votable)

			einsteinCoeffData = votable.getTable( constants.EinsteinTable.einsteinTableId )
			energyTableData = votable.getTable( constants.EnergyTable.energyTableId )
			ratesData = votable.getTable( constants.RateCoefficientTable.rateCoefficientsTableId )
			effectiveRatesData = votable.getTable( constants.RateCoefficientTable.effectiveRateCoefficientsTableId )
			referencesData = votable.getTable( constants.ReferenceTable.referencesTableId )
			
			filewriter.writeRatesFile (ratesData, tableParams, outputDir, buildName(tableParams, "short"), "")
			filewriter.writeRatesFile (effectiveRatesData, tableParams, outputDir, buildName(tableParams, "short"), constants.Global.effectiveRatesName)
			filewriter.writeReferences(referencesData, tableParams, outputDir )
			
			if allFiles == True :
				filewriter.writeEinsteinFile(einsteinCoeffData, tableParams, outputDir, buildName(tableParams, "long"))
				filewriter.writeEnergyFile (energyTableData, tableParams, outputDir, buildName(tableParams, "long"))

		i = i+1	

		
	if noElement == True : 
		print("No element from elements.txt available in database.")
		return False
	
	return True
		
		
		
def getElementsFile(votable):
	"""
		Writes the list of available molecules in elements.txt file (or date_elements.txt if the file exist already)
			votable votable returned by the distant service
	"""
	#get all the elements contained in the table
	elementList = votableutil.getFieldData(votable, constants.ElementList.name)
	processes = votableutil.getFieldData(votable, constants.ElementList.processes)
	symmetries = votableutil.getFieldData(votable, constants.ElementList.symmetries)
	nouvFichier = ""
	
	#if elements file does not exist it is created
	if os.path.exists(constants.Global.elementFile) == False:
		nouvFichier = open(constants.Global.elementFile, "w")
	#new file with the date in it
	else :
		nouvFichier = open(str(datetime.date.today())+constants.Global.separator+constants.Global.elementFile, "w")
	
	nouvFichier.write(constants.Global.elementFileComment+"\n")
	
	cpt=0;
	for value in elementList :		
		nouvFichier.write(value[0]+"\t\t")
		infos = constants.ElementList.commentIndicator+"processes : "+processes[cpt][0]
		if symmetries[cpt][0] != constants.Global.emptySymmetry:
			infos = infos+" - symmetries : "+symmetries[cpt][0]
		nouvFichier.write(infos+"\n")
		cpt = cpt+1
	nouvFichier.close()	

		
def initDirectories(outputDirectory, extension) :
	"""
		creates directories in which files will be stored	
			outputDirectory  : main directory containing files created during this execution of the program
			prefix : prefix of the directory (A, C, S )
	"""
	i=0

	outputDirectory = os.path.join(outputDirectory, extension+constants.Global.separator+datetime.date.today().strftime("%Y-%m-%d") )  	
	if (os.path.exists(outputDirectory)==False) :
		os.mkdir(outputDirectory, 0o755)				
	
	#create a new directory and add a number to differentiate it from the others
	else :
		i=1
		while(os.path.exists(outputDirectory+constants.Global.separator+str(i))==True) :
			i=i+1
		outputDirectory= outputDirectory+constants.Global.separator+str(i)
		os.mkdir(outputDirectory, 0o755)	
		
	if (os.path.exists(os.path.join(outputDirectory, constants.Global.ratesDirectory))==False) :
		os.mkdir(os.path.join(outputDirectory, constants.Global.ratesDirectory), 0o755)
		
	return outputDirectory

def buildName (table, mode):
	"""
		creates a filename from the data contained in a votable
		only uses the name of the target and its symmetry		
			data : votable containing the data
			mode : include name of the processus if mode == long
	"""
	targetName=table.get( constants.GlobalParams.targetElement )
	targetSymmetry=table.get( constants.GlobalParams.targetElementSymmetry )
	processus=table.get( constants.GlobalParams.processus)

	if (targetSymmetry == constants.Global.emptySymmetry) : 
		targetSymmetry = ""
	else : 
		targetSymmetry = constants.Global.separator+targetSymmetry

	if(mode == "long"):
		return  targetName+targetSymmetry+constants.Global.separator+processus
	if(mode == "short"):
		return targetName


def buildNameCollision (table):
	"""
		creates a filename from the data contained in a votable
		uses the name of the target, the collider and their respective symmetry		
			table : votable containing the data
	"""
	targetName=table.get( constants.GlobalParams.targetElement)
	targetSymmetry=table.get( constants.GlobalParams.targetElementSymmetry)
	colliderName=table.get( constants.GlobalParams.colliderElement)
	colliderSymmetry=table.get( constants.GlobalParams.colliderElementSymmetry)
	processus=table.get( constants.GlobalParams.processus)
	
	if (targetSymmetry == constants.Global.emptySymmetry) : 
		targetSymmetry = ""
	else : 
		targetSymmetry = constants.Global.separator+targetSymmetry
	
		
	if (colliderSymmetry == constants.Global.emptySymmetry) :
		colliderSymmetry = ""
	else : 
		colliderSymmetry = constants.Global.separator+colliderSymmetry
		
	fileName = targetName+targetSymmetry+constants.Global.separator+colliderName+colliderSymmetry+constants.Global.separator+processus	

	return fileName	

def lookForModifiedFiles(rootDirectory, datedDirectory):
	"""
		looks for modified files in the last update compared to the previous one	
			rootDirectory  : directory containing all the others
			datedDirectory : directory containing the result of one execution of the program
	"""
	directories = os.listdir(rootDirectory)
	directories.sort()
	
	#removes svn directory from list
	if directories[0]== '.svn':
		directories.pop(0)	
	
	today = datetime.date.today()
	newLogFile = open(os.path.join(rootDirectory, datedDirectory, constants.Global.logFile),"w")
	
	#this is the first run, .svn must be removed from the directory
	if (len(directories) == 1) : 
		newLogFile.write("First update : "+ today.strftime("%Y-%m-%d"))

	#compares with previous run
	if (len(directories)>1) :
		#path to last data downloaded
		newVersionPath = os.path.join(rootDirectory,datedDirectory)		
		newDirectory = datedDirectory.split(constants.Global.separator)
		i=0		
		found = False
		
		#searches position of the new directory in the list
		while(found == False):
			if (directories[i] == datedDirectory):
				found = True
			else:
				i = i+1
				
		found = False			
		oldDirectory = directories[i-1].split(constants.Global.separator)

		if(oldDirectory[0] == newDirectory[0]) :
			found = True

		#path to previous data downloaded
		lastVersionPath = os.path.join(rootDirectory,directories[i-1])
		
		#directories for new data (ascii, energytables ...)
		newVersionDirectories = os.listdir(newVersionPath)
		#directories for previous data (ascii, energytables ...)
		lastVersionDirectories = os.listdir(lastVersionPath)
		
		if (found == True):
			newLogFile.write("Update date : "+today.strftime("%Y-%m-%d")+"\n\n")
			
			cpt = 0
			for directory in newVersionDirectories :
				compare(directory, newVersionPath, lastVersionPath, newLogFile)
			
			newLogFile.write("       ##############################\n\n")	
			oldLogFile = open(os.path.join(lastVersionPath, constants.Global.logFile),"r")
			lines = oldLogFile.readlines()
			oldLogFile.close()
			
			for i in lines : 
				newLogFile.write(i)
		else:
			newLogFile.write("First update : "+ today.strftime("%Y-%m-%d"))
			
	newLogFile.close()

def compare(element, newDirectoryPath, oldDirectoryPath, file):
	"""
		compares 2 files with the same name but in different directories	
			element : name of the file to compare
			newDirectory_path : newly created directory
			oldDirectory_path : directory containing the result of the previous execution
			file : log file in which modification are written
	"""
	if (not os.path.isfile(os.path.join(newDirectoryPath,element))):
		directories = os.listdir(os.path.join(newDirectoryPath,element))

		for directory in directories :
			compare(directory, os.path.join(newDirectoryPath,element), os.path.join(oldDirectoryPath,element), file)
			
	else :
		if (element != constants.Global.logFile and element != constants.Global.tmpXmlFile \
			and element != constants.Global.collisionTables and element != constants.Global.molList) :
			if (os.path.exists(os.path.join(oldDirectoryPath,element))==True ) :
			
				#old version of the file
				oldFile = open(os.path.join(oldDirectoryPath,element), "r")
				oldContent = oldFile.read()
				oldArray = oldContent.split(constants.Global.headerDataSeparator)
				
				#new version of the file
				newFile = open(os.path.join(newDirectoryPath,element), "r")
				newContent = newFile.read()
				newArray = newContent.split(constants.Global.headerDataSeparator)
				
				#compare header of the files
				compareContent(oldArray[0], newArray[0], file, element, "header of ")
				#compare data contained in files
				compareContent(oldArray[1], newArray[1], file, element, "data of ")
				
			else :
				file.write(element+" has been added \n")	
	
def compareContent(oldContent, newContent, logFile, element, text):
	"""
		writes in the log file any difference between the two contents	
		oldContent : string containing the header of the old file
		newContent : string containing the header of the new file
		logFile : log file containing the list of modifications
		element : element whose file has been modified
		text : text to write in the log file for each modification
	"""	
	if (oldContent != newContent) : 
		logFile.write(text+" "+element+" has been modified \n")		
