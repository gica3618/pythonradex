import sys
import os
import urllib.request, urllib.parse, urllib.error
import string

sys.path.append(os.path.join("src/classes"))
import constants
import votableutil

isSetText = 0


def createMoldat(directory):
	"""
		creates the mol_list.dat file
			directory : directory where the file is created
	"""
	strList = []
	
	# file header
	strList.append(constants.MolDatFile.collisionTableId)
	
	
	strList.append(completeLine("mol_name", 30))
	strList.append(completeLine("N_lev", 15))
	strList.append(completeLine("mol_mass", 15))
	
	strList.append("\n>\n")
	
	fileName =  os.path.join(directory, constants.Global.molList)
	nouvFichier = open(fileName, "a") 	
	nouvFichier.write(''.join(strList))
	nouvFichier.close()
	
	

def writeElementList(votable, params, directory) :
	"""
		fills the mol_list.dat file   
		   votable : table containing the data
		   params : list of param fields
		   directory : directory where the file will be written
	"""
	fileName =  os.path.join(directory, constants.Global.molList)
	strList = []	
	symmetry = "";
	
	if (params.get(constants.GlobalParams.targetElementSymmetry) != constants.Global.emptySymmetry):
		symmetry = constants.Global.separator+params.get(constants.GlobalParams.targetElementSymmetry)
	
	# format : 'element_symmetry_processus'
	strList.append(completeLine("'"+params.get(constants.GlobalParams.targetElement)+symmetry+constants.Global.separator+params.get(constants.GlobalParams.processus)+"'", 30))
	strList.append(completeLine(votableutil.getParamValue(votable,constants.EnergyTable.numberOfLevels), 15))
	strList.append(completeLine(params.get(constants.GlobalParams.targetMolecularMass), 15))
	
	strList.append("\n")

	nouvFichier = open(fileName, "a")
	nouvFichier.write(''.join(strList))
	nouvFichier.close()


def completeLine(string, size, char= ' '):
	"""
		completes a string until it reaches a given size by adding a character at the end	 		
			string : string to complete
			size : size to reach
			char : char used to complete the string
	"""
	if(len(string) >= size) :
		return(string)
	else :
		return(completeLine(char+string, size, char))

def writeList(table, row, fieldName, fieldSize, format="") :	
	"""
		writes data in a file and remove html entities
		get the content from a row of data and identify it thanks to the name of the field	
			table: table containing data
			row: content of a TR element in the votable
			fieldName : name of a field element in the votable
			fieldSize : number of characters of the string to write
			format : format used to write data
	"""
	results = votableutil.getTableColumn(table, fieldName)
	strList = []

	for coln in results:			
		tmp = votableutil.getSelectedData(row, coln)[0]
		
		if(format == ""):
			strList.append(completeLine(urllib.parse.unquote_plus(str(tmp)), fieldSize))
		else : 
			tmp = format % float(tmp)
			strList.append(completeLine(tmp, fieldSize))
		
	return ''.join(strList)



def writeQuantumNumbersList(table, row, fieldName, qnNames, fieldSize) :	
	"""
		function specifically dedicated to the writing of quantum numbers	
			table : table containing data
			row: content of a TR element in the votable
			fieldName : name of a field element in the votable
			qnNames : array containing the fields of the table
			fieldSize : number of characters of the string to write
	"""
	results = votableutil.getTableColumn(table, fieldName)
	strList = []
	#position at which we can find the name of the quantum numbers
	i=constants.EinsteinTable.quantumNumbersNamePosition
	strList.append("'")
	for coln in results:			
		tmp = votableutil.getSelectedData(row, coln)[0]		
		strList.append(qnNames[i]['name']+" = "+urllib.parse.unquote_plus(str(tmp)+"  "))		
		i = i+1
	strList.append("'")
	return completeLine(''.join(strList), fieldSize)

	
def writeEinsteinFile (table, params, directory, name):
	"""
		writes the data of a table containing einstein coefficients (.aij files)
			table : votable
			source  : tmp file where the votable is stored
			directory : directory where the file will be created
			name : name of the file
	"""
	targetName=params.get(constants.GlobalParams.targetElement)
	targetSymmetry = params.get(constants.GlobalParams.targetElementSymmetry)
	
	if(targetSymmetry ==  constants.Global.emptySymmetry ):
		targetSymmetry= ""
	
	sourceDatabase = votableutil.getParamValue(table, constants.EinsteinTable.source)
	fileName =  os.path.join(directory, name+constants.Global.einsteinExtension)
	strList = []
	nouvFichier = open(fileName, "w") 	
	strList.append("Einstein coefficients A_ij for "+targetName+" "+targetSymmetry+"\n")	
	strList.append("source database : "+sourceDatabase+"\n")	
	strList.append("       I       J            A_ij (s^{-1})    \n")
	strList.append(constants.Global.headerDataSeparator+"\n")
	nouvFichier.write(''.join(strList))
	
	rows = votableutil.getTableRows(table)
	
	for row in rows:
		strList = []
		strList.append(writeList(table, row, constants.EinsteinTable.initialLevel, 8))
		strList.append(writeList(table, row, constants.EinsteinTable.finalLevel, 8))
		strList.append(writeList(table, row, constants.EinsteinTable.value, 20, "%.6e"))
		strList.append("\n")
		nouvFichier.write(''.join(strList))	
	nouvFichier.write('\n')

def writeEnergyFile (table, params, directory, name):
	"""
		writes the data of a table containing energies	(.lev files)
			table : votable
			params : list of param fields
			directory : directory where the file will be created
			name : name of the file
	"""
	fileName =  os.path.join(directory, name + constants.Global.energyExtension)	
	title=votableutil.getParamValue(table, constants.EnergyTable.title)
	sourceDatabase = votableutil.getParamValue(table, constants.EnergyTable.source)
	array = votableutil.getFieldsAttrs(table)
	description = votableutil.getFieldsDescription(table)

	if (not os.path.exists(fileName)) :
		strList = []
		nouvFichier = open(fileName, "w") 
		strList.append(title+"\n")
		strList.append("source database : "+sourceDatabase+"\n")

		cpt=0	
		for fields in array :
			if cpt > 2 :
				strList.append(fields['name']+" : "+description[cpt-3]+"\n")
			cpt = cpt+1
		
		strList.append(completeLine("N",3))
		strList.append(completeLine("g",6))
		strList.append(completeLine("Energy in cm^{-1}",20))		
		nouvFichier.write(''.join(strList))	
		nouvFichier.write("\n>\n")

		rows = votableutil.getTableRows(table)		
		for row in rows:	
			strList = []		
			strList.append(writeList(table, row, constants.EnergyTable.level, 3))	
			strList.append(writeList(table, row, constants.EnergyTable.degeneracy, 6))	
			strList.append(writeList(table, row, constants.EnergyTable.energy, 25, "%.9e"))
			strList.append(writeQuantumNumbersList(table, row, constants.EnergyTable.quantumNumber, array, 70))
			strList.append("\n")
			nouvFichier.write(''.join(strList))		
		nouvFichier.write('\n')
		writeElementList(table, params, directory)

def writeRatesFile (table, params, directory, name, ratesType):
	"""	
		writes the data of a table containing rate coefficients (.kij files)
			table : votable
			params  : list of param fields
			directory : directory where the file will be created
			name : name of the file
			ratesType : type of the coefficients (state to state, effective)
	"""
	rows = votableutil.getTableRows(table)

	#if there is no data row, nothing is done
	if (len(rows)!=0) :	
		strList = []		
		idCollision=params.get(constants.GlobalParams.idCollision)
		if (ratesType != "")  :
			ratesType = constants.Global.separator+ratesType
		else :
			ratesType = constants.Global.separator+constants.Global.stateTostateRatesName
		
		fileName =  os.path.join(directory,constants.Global.ratesDirectory, name+constants.Global.separator+idCollision+ratesType+constants.Global.ratesExtension)
		nouvFichier = open(fileName, "w") 	
		nbTemperatures = votableutil.getParamValue(table, constants.RateCoefficientTable.numberOfTemperatures)
		
		strList.append(params.get(constants.GlobalParams.collisionTitle))
		strList.append("\n"+constants.Global.headerDataSeparator+"\n")
		strList.append("Number of temperature columns = "+nbTemperatures+"\n\n")
		strList.append("       I       J       Temperature (K)    \n\n")	
		
		nouvFichier.write(''.join(strList))	
		cpt=0
		
		#add the list of temperatures
		for row in rows:
			if (cpt < int(nbTemperatures) ) :				
				results = votableutil.getTableColumn(table, constants.RateCoefficientTable.temperature) 
				results.sort()			
				tmp = votableutil.getSelectedData (row, results[0])[0] 
				if (cpt == 0 ) :
					nouvFichier.write(completeLine(str(tmp), 32))
				else :
					nouvFichier.write(completeLine(str(tmp), 20))
			else :
				break
			cpt=cpt+1
		
		nouvFichier.write('\n')	
		
		rows = votableutil.getTableRows(table)
		cpt=0
		strList = []	
		for row in rows:					
			#add the titles of the columns
			if (cpt%int(nbTemperatures) == 0 ) :
				strList.append("\n")	
				strList.append(writeList(table, row, constants.RateCoefficientTable.targetInitialLevel, 8))
				strList.append(writeList(table, row, constants.RateCoefficientTable.targetFinalLevel, 8))
				
			#add the data
			strList.append(writeList(table, row, constants.RateCoefficientTable.data, 20, "%.6e"))
			
			cpt = cpt+1
		strList.append("\n")
		nouvFichier.write(''.join(strList))		

def writeReferences(table, params, directory ) :
	"""
		writes the references contained in Basecol concerning a dataset
			table : votable
			params : list of param fields
			directory : directory where the file will completed
	"""
	idCollision = params.get(constants.GlobalParams.idCollision)
	collisionTitle = params.get(constants.GlobalParams.collisionTitle)
	nbOfReferences = votableutil.getParamValue(table, constants.ReferenceTable.numberOfValues)
	rows = votableutil.getTableRows(table)
	
	filesList =  os.listdir(os.path.join(directory, constants.Global.ratesDirectory))
	for file in filesList:
		if(file != constants.Global.collisionTables and file != constants.Global.tmpFile):
			tableau = file.split(constants.Global.separator)

			if (len(tableau)==3 and tableau[1]==idCollision) :
				
				ratesFile = open(os.path.join(directory, constants.Global.ratesDirectory, file), "r")
				fileNameElements = tableau[2].split(".")
				ratesType = fileNameElements[0]
				fileExtension = fileNameElements[1]
				contenu = ratesFile.read()
				ratesFile.close()
				tmp = open(os.path.join(directory, constants.Global.ratesDirectory, constants.Global.tmpFile), "w")	
				tmp.write("References :   ")
				
				for row in rows:
					strList = []
					strList.append(writeList(table, row, constants.ReferenceTable.authors, 8))
					strList.append(writeList(table, row, constants.ReferenceTable.journal, 8))
					strList.append(writeList(table, row, constants.ReferenceTable.volume, 0))
					strList.append(writeList(table, row, constants.ReferenceTable.pages, 0))
					
				references = ','.join(strList)
				references = references.replace(';,', ',')
				
				#add references at the beginning of kij file
				tmp.write(references+"\n")	
				tmp.write(contenu)
				tmp.close()
				
				filepath = os.path.join(directory, constants.Global.ratesDirectory, str(tableau[0])+constants.Global.separator+str(tableau[1])+"."+fileExtension)
	
				os.remove(os.path.join(directory, constants.Global.ratesDirectory, file))
				os.rename(os.path.join(directory, constants.Global.ratesDirectory, constants.Global.tmpFile), filepath)			

				writeCollisionsTable (directory, filepath, references, collisionTitle+"  "+ratesType)

def getFreeFileName(file) :
	"""
		verifies if a file already use a name and return a usable name if its the case	
			file  : name to test
	"""
	i=0
	if (os.path.exists(file)==False) :
		return file
	else :
		i=1
		newfile = file.split(".")
		while(os.path.exists(newfile[0]+constants.Global.separator+str(i)+"."+newfile[1])==True) :
			i=i+1
		file= newfile[0]+constants.Global.separator+str(i)+"."+newfile[1]
		return file

def writeCollisionsTable (directory, filePath, references, collisionTitle):
	"""
		completes the collision_tables.dat file	
			directory  : directory where the file is located
			filePath : string that will be added in the collision_tables.dat file, contains the name of a new file
			references :  string that will be added in the collision_tables.dat file, contains the references of a collision
			collisionTitle : complete title of the collision
	"""
	global isSetText
	fileElement = os.path.split(filePath)
	fileName = fileElement[len(fileElement)-1]

	strList = []
	
	nouvFichier = open(os.path.join(directory, constants.Global.ratesDirectory,constants.Global.collisionTables), "a")	
	if (isSetText == 0):
		nouvFichier.write("List of available tables of collision rates.\n")	
		strList.append('\n>\n')
		
	strList.append(fileName)
	strList.append('\n')
	strList.append(collisionTitle)
	strList.append('\n')
	strList.append(references)
	strList.append("\n   ******************\n")
	nouvFichier.write(''.join(strList))
	nouvFichier.close()	
	isSetText = 1
