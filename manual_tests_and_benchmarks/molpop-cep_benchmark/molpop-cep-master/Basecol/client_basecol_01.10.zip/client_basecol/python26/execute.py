#!/usr/bin/python
import os
import sys
import gc
from httplib import HTTPConnection
import datetime
import time
import getopt
import shutil
import string

#import local libraries
sys.path.append(os.path.join(".","src"))
import filemanager 
import constants
from ConfigReader import ConfigReader
from VOTable import VOTable

def main():
    """ 
    Available options are :
    no option 		gets all data for the selected elements
    -a, --all 		gets all data for all the listed elements (including those de-selected)
    -c, --collision gets only collision rates for the selected elements
    -e, --elements 	generates a new elements.txt listing all available entries  
    -h, --help 		displays help
    
    """ 	
    # parse command line options
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hcae", ["help", "collisions", "all", "elements"])
    except getopt.error as msg:
        print(msg)
        print("for help use --help")
        sys.exit(2)
      
    #selected files only     
    extension = "S"
    opts.sort()
    #no option, write all files
    if len(opts) == 0 :
        getCollisions(False, True, extension)
    else :
        allFiles = True
        allElements = False
        collisions = False
        elements = False
        
        for o, a in opts:
            if o in ("-h", "--help"):
                print(main.__doc__)
                sys.exit(0)
            
            #all data, all elements
            if o in ("-a", "--all"):
                allElements = True
                collisions = True
                extension = "A"            
            
            #collision data
            if o in ("-c", "--collisions"):
                allFiles = False
                collisions = True
                extension = "C"+extension
                
            #only create elements file
            if o in ("-e", "--elements"):
                elements = True
                
        if elements == True :
            getElements()				
        else :
	        getCollisions(allElements, allFiles, extension)

def getCollisions(allElements, allFiles, extension):
    """
        writes the data files
            allElements true if all the elements in the elements.txt file are processed
            alFiles true if all the files are generated, false for kij only
            directory directory where files will be written 
    """
    config = ConfigReader(os.path.join(os.getcwd(), ".." ,constants.Global.configDirectory, constants.Global.configFile))
    
    #create output directories
    outputDirectory=filemanager.initDirectories(config.getOutputDirectory(), extension)
    
    #create temporary file    
    tmpfile = os.path.join(outputDirectory, constants.Global.tmpXmlFile)
    
    #send a request and put the votable in the tmp file
    connection = HTTPConnection(config.getServer())
    connection.request(config.getMethod(), config.getCollisionsUrl())
    resp = connection.getresponse()
    open(tmpfile,"w").write(resp.read())
    
    votable = VOTable(tmpfile)
    
    #get all the files pointed by the urls
    result = filemanager.getFiles(config.getServer(), config.getMethod(), tmpfile, outputDirectory, votable, constants.ReferenceTable.referencesTableId, allElements, allFiles)
    
    #allow to close some files when running in windows environnement
    gc.collect()
    os.remove(tmpfile)    

    #identify all the modified files since the previous execution
    if result == True:
        newDirectory = (string.split(outputDirectory, os.path.sep))[1];
        filemanager.lookForModifiedFiles(config.getOutputDirectory(), newDirectory)
    else :
        #remove directory if the run was unsuccessfull
        shutil.rmtree(outputDirectory)    
    
def getElements():
    config = ConfigReader(os.path.join(os.getcwd(), "..",constants.Global.configDirectory, constants.Global.configFile))
    tmpfile = os.path.join(constants.Global.tmpXmlFile)
    #send a request and put the votable in the tmp file
    connection = HTTPConnection(config.getServer())
    connection.request(config.getMethod(), config.getElementsUrl())
    resp = connection.getresponse()
    open(tmpfile,"w").write(resp.read())
    votable = VOTable(tmpfile)
    
    #get all the files pointed by the urls	
    filemanager.getElementsFile(votable)	
    
    #allow to close some files when running in windows environnement
    gc.collect()
    os.remove(tmpfile)	


if __name__ == "__main__":
	main()
	
	

	
	
	
	
	
	
	
	
	
	
	

