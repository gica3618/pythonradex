class Global:
	"""Generic container for shared variables."""
	molList = 'mol_list.dat'	
	collisionTables = 'collision_tables.dat'
	tmpFile = 'tmp.txt'
	elementFile = 'elements.txt'
	elementFileComment = '# This is the list of molecules available as of Sep. 9, 2009. Please check the Basecol site for updates or run the program with -e|--elements option.\n# The tool will download information for the species not commented out with "#".\n# Executing with the option -a (or --all) will run through the full list, irrespective of "#" marks.'
	logFile = 'log.txt'
	tmpXmlFile = 'sortie.xml'
	configFile = 'config.xml'
	einsteinExtension = '.aij'
	energyExtension = '.lev'
	ratesExtension = '.kij'
	ratesDirectory = 'Coll'
	configDirectory = 'configuration'
	headerDataSeparator = '>'
	effectiveRatesName = 'effective'
	stateTostateRatesName = 'stateTostate'
	emptySymmetry = 'none'
	separator = '_'
	

class MolDatFile : 
	collisionTableId = "This file contains the MOLPOP molecular list. A molecule whose mol_name is, e.g., XYZ should have a data file XYZ.lev with listing of N_lev energy levels,\n and XYZ.aij tabulating their A-coefficients. mol_mass is the mass number.  When adding another molecule make sure to terminate every data line with CR. \n\n"
	
	
class ElementList:
	name = "name";
	molecularMass ="molecular_mass"
	molecularConstant = "molecular_constant"
	processes = "processes"
	symmetries = "symmetries"
	commentIndicator = "#"
	
class CollisionTable:
	collisionTableId = "collisions"
	idCollision = "id_collision"	
	collisionReferences = "collision_references"	
	numberOfLevels = "number_of_levels"	
	targetMolecularMass = "target_molecular_mass"	
	targetMolecularConstant = "target_molecular_constant"	
	processus = "processus"	
	collisionTitle = "collision_title"	
	targetElement = "target_element"	
	colliderElement = "collider_element"	
	targetSymmetry = "target_symmetry"	
	colliderSymmetry = "collider_symmetry"
	
class GlobalParams :
	targetElement = "target_element"
	targetElementSymmetry = "target_element_symmetry"		
	colliderElement = "collider_element"
	colliderElementSymmetry = "collider_element_symmetry"
	collisionTitle = "collision_title"
	processus = "processus"
	targetMolecularMass = "target_molecular_mass"
	targetMolecularConstant = "target_molecular_constant"
	idCollision = "id_collision"
	
class EinsteinTable:
	einsteinTableId = "einsteinCoeff"
	source = "einstein_spectroscopic_database"
	initialLevel = "target_initial_level"
	finalLevel = 'target_final_level'
	value = "einstein_coefficient"
	quantumNumbersNamePosition = 3

class EnergyTable:
	energyTableId = "energyTable"
	numberOfLevels = 'number_of_levels'
	jMax = 'target_j_max'
	title = 'energy_table_title'
	source = 'levels_spectroscopic_database'
	level = 'level'
	energy = 'energy'
	degeneracy = 'degeneracy'
	quantumNumber = 'phys.atmol.qn'
	
class RateCoefficientTable:
	rateCoefficientsTableId = "normal_rateCoefficients"
	effectiveRateCoefficientsTableId = 'effective_rateCoefficients'
	numberOfTemperatures = 'number_of_temperatures'
	targetInitialLevel = 'target_initial_level'
	targetFinalLevel = 'target_final_level'
	temperature = 'temperature'
	data = 'data'


class ReferenceTable:
	referencesTableId = 'references'
	numberOfValues = 'number_of_values'
	authors = 'authors'
	title = 'title'
	journal = 'journal'
	year = 'year'
	volume = 'volume'
	pages = 'pages'
	mainReference = 'main_reference'
